package utils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class Customer {
	
	public String customerId;	
	private Map<String, Order> customerOrderList = new HashMap<>();
	private ArrayList<Order> custOrderSequence = new ArrayList<>();
	
	public static int MaxOrderListLength = 0;
	
	public Customer() {

	}
	
	public Customer(String custid, String ordid, String orddate, int prodid) {
		this.customerId = custid;
		Order ord = new Order(ordid, orddate, prodid);
		AddOrder(ord);
	}

	private void AddOrder(Order ord) {
		customerOrderList.putIfAbsent(ord.orderId, new Order());
		customerOrderList.get(ord.orderId).orderId = ord.orderId;
		customerOrderList.get(ord.orderId).orderDate = ord.orderDate;
		customerOrderList.get(ord.orderId).AddProductList(ord.getOrdProductsList());		
	}

	public Map<String, Order> getCustomerOrderList(){
		return customerOrderList;
	}

	public void AddOrderList(Map<String, Order> custOrdList) {
		for (Entry<String, Order> entry : custOrdList.entrySet()) {
			String ordId = entry.getKey();
			AddOrder(custOrdList.get(ordId));
		}
	}
	
	public ArrayList<Order> getCustOrderSeq(){
		return custOrderSequence;
	}
	
	public int getCustOrderSeqSize(){
		return custOrderSequence.size();
	}

	public int getTotalProductCount() {
		int totalproductcount = 0;		
		for (int i = 0; i < custOrderSequence.size(); i++)
			totalproductcount = totalproductcount + custOrderSequence.get(i).getOrdProductsListSize();			
		return totalproductcount;
	}

	public void sortOrderByOrderDate() {
		List<Map.Entry<String, Order>>  customerOrderListAfterSord = new ArrayList<Map.Entry<String, Order>>(customerOrderList.entrySet());		
		Collections.sort(customerOrderListAfterSord, new Comparator<Map.Entry<String, Order>>() {
			public int compare(Map.Entry<String, Order> o1, Map.Entry<String, Order> o2) {
				return (o1.getValue().compareTo(o2.getValue()));
			}
		});		
		customerOrderList = null;		
		//�����
		custOrderSequence.clear();
		for (int i = 0; i < customerOrderListAfterSord.size(); i++) {
			Order order = new Order(customerOrderListAfterSord.get(i).getValue());
			custOrderSequence.add(order);
		}		

	}
	
	public int getOrderCount() {
		int OrderCount = custOrderSequence.size();
		MaxOrderListLength = (MaxOrderListLength > OrderCount)? MaxOrderListLength : OrderCount;
		return OrderCount;
	}

	public void setOrderSequence(ArrayList<Order> custOrderList) {		
		this.custOrderSequence = custOrderList;
	}

}
