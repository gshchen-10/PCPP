package utils;

import java.text.ParseException;

public class PCPMiner {

	private RetailDatabase retailDatabase;
	private SeqVerticalDatabase seqVertDatabase;
	
	int pcps = 0;
	
	long startTimestamp = 0;
	long endTimeStamp = 0;
	
	public PCPMiner(String inputFile, int minOrderCount) {
		retailDatabase = new RetailDatabase(inputFile);
		retailDatabase.Preprocessing(minOrderCount);
	}

	public void Running(float coef, float noiRat, int eps, float minpts, int numberOfClusters) throws ParseException {
		
		startTimestamp = 0;
		endTimeStamp = 0;
		startTimestamp = System.currentTimeMillis();

		seqVertDatabase = new SeqVerticalDatabase(retailDatabase);
		pcps = seqVertDatabase.periodicClusterPatternMining(coef, noiRat, eps, minpts, numberOfClusters);
		
		endTimeStamp = System.currentTimeMillis();
		MemoryLogger.getInstance().checkMemory();
		
	}
	
	public void printStatistics(String dataset) {
		StringBuilder r = new StringBuilder(200);	
		r.append("===========  " + dataset + "  ============\n");
		r.append("Number of PCP: ");
		r.append(pcps);		
		r.append("\n");
		r.append("Run time: ");
		r.append((endTimeStamp - startTimestamp) / 1000f);
		r.append(" s \n");
		r.append("Max memory (mb): " );
		r.append( MemoryLogger.getInstance().getMaxMemory());
		r.append('\n');		
		r.append("=================================\n");  

		System.out.println(r.toString());		
	}
}
