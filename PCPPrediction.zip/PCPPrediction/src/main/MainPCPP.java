package main;

import java.text.ParseException;

import utils.PCPPrediction;

public class MainPCPP {

	public static void main(String[] args) throws ParseException {		

		String dataset = "tmall";   // tafeng  coop100  tmall  x5retailhero
		
		String inputPath = ".\\data\\" + dataset + ".txt";

		int minOrderCount = 9;
		
		float coefficientOfVariation = 0.5f;
		int numberOfClusters = 5;
		float noiseRatio = 0.2f;
		int epsilon = 1;
		float minPtsRatio = 8;		
		
		int recommendedItemsNumber = 6;
		
		if (dataset.equals("tafeng")) {
			
			coefficientOfVariation = 0.56f;
			numberOfClusters = 3;
			noiseRatio = 0.2f;
			epsilon = 1;
			minPtsRatio = 8;
			
			recommendedItemsNumber = 6;
			
		} else if (dataset.equals("tmall")) {
			
			coefficientOfVariation = 0.5f;
			numberOfClusters = 5;
			noiseRatio = 0.25f;
			epsilon = 1;
			minPtsRatio = 8;
			
			recommendedItemsNumber = 3;
			
		} else if (dataset.equals("x5retailhero")) {
			
			coefficientOfVariation = 0.55f;
			numberOfClusters = 6;
			noiseRatio = 0.2f;
			epsilon = 1;
			minPtsRatio = 12;
			
			recommendedItemsNumber = 5;
			minOrderCount = 20;
			
		} else if (dataset.equals("coop100")) {
			
			coefficientOfVariation = 0.25f;
			numberOfClusters = 5;
			noiseRatio = 0.2f;
			epsilon = 1;
			minPtsRatio = 3f;
			
			recommendedItemsNumber = 9;
			
		} else {
			return;
		}	
			
		PCPPrediction pcpp = new PCPPrediction(inputPath, minOrderCount);
		pcpp.Running(coefficientOfVariation, noiseRatio, epsilon, minPtsRatio, numberOfClusters, recommendedItemsNumber);
		pcpp.printStatistics(dataset);
			
	}

}
