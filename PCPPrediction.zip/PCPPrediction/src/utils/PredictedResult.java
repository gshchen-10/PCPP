package utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.math3.distribution.NormalDistribution;

public class PredictedResult {
	
	public Map<String, ArrayList<Integer>> custProductRank;
	
	RetailDatabase retailDatabase;
	SeqVerticalDatabase seqVertDatabase;
	
	public double F1Score = 0;
	public double Precison = 0;
	public double Recall = 0;
	public double HitRatio = 0;
	
	public PredictedResult(RetailDatabase retailData, SeqVerticalDatabase seqvert) {
		
		this.retailDatabase = retailData;
		this.seqVertDatabase = seqvert;
		custProductRank = new HashMap<>();
		
	}
	
	public int patternsPrediction(int recommendedItemsNumber) throws ParseException {
		
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		
		for (int i = 0; i < retailDatabase.getCustomersListSize(); i++) {
			String custID = retailDatabase.getCustomersList().get(i).customerId;
			ArrayList<PeriodicItem> periodItems = seqVertDatabase.periodicItemList.get(custID);
			if (periodItems == null) {
				continue;
			} else {
				for (int j = 0; j < periodItems.size(); j++) {
					int productID = periodItems.get(j).item;
					int index = seqVertDatabase.seqVertBitList.get(productID).getSupportSeqID().indexOf(i);
					Date dateOfLastOccur = seqVertDatabase.seqVertBitList.get(productID).getEmbeddings().get(index).get(seqVertDatabase.seqVertBitList.get(productID).getEmbeddings().get(index).size() - 1);
					Date dateOfNextTransaction = formatter.parse(retailDatabase.testSet.get(custID).orderDate);
					double mean = periodItems.get(j).meanPeriod;
					double stdvar = periodItems.get(j).stdVariance;
					if ((dateOfLastOccur.getTime() + mean - stdvar) < dateOfNextTransaction.getTime() && dateOfNextTransaction.getTime() < (dateOfLastOccur.getTime() + mean + stdvar)) {
						custProductRank.putIfAbsent(custID, new ArrayList<>());
						custProductRank.get(custID).add(productID);
					}
				}
			}
		}      
				
		for (int i = 0; i < retailDatabase.getCustomersListSize(); i++) {
			Customer cust = retailDatabase.getCustomersList().get(i);
			String custID = cust.customerId;
			List<PeriodicClusterPattern> periodicClustPat = cust.getPeriodicClustPattList();
			Map<Integer, Float> recommendedProducts = new HashMap<>();
			for (int j = 0; j < periodicClustPat.size(); j++) {
				int productID = periodicClustPat.get(j).getProductId();
				if (cust.distinctItems.indexOf(productID) < 0) {
					continue;
				} else {
					Date nextDate = formatter.parse(retailDatabase.testSet.get(custID).orderDate);
					Date begDate = formatter.parse(retailDatabase.beginDate);
					float nextTime = (nextDate.getTime() - begDate.getTime()) / (1000 * 60 * 60 * 24);
					float lastPeriod = nextTime - periodicClustPat.get(j).getLastCenter();
					float probability = 0;
					if (periodicClustPat.get(j).getStandVari() != 0) {
						NormalDistribution dis = new NormalDistribution(periodicClustPat.get(j).getAveragePeriod(), periodicClustPat.get(j).getStandVari());
						float weightProb = 0.0f;
						for (Entry<Integer, Integer> entry : periodicClustPat.get(j).getDiameterDistribute().entrySet()) {
							float radius = entry.getKey() / 2.0f;
							float prob = (float)dis.probability(lastPeriod - radius, lastPeriod + radius);
							weightProb += (prob * entry.getValue());
						}
						probability = weightProb / periodicClustPat.get(j).getClusterNum();
					} else {
						int hitTimes = 0;
						for (Entry<Integer, Integer> entry : periodicClustPat.get(j).getDiameterDistribute().entrySet()) {
							float radius = entry.getKey() / 2.0f;
							if (lastPeriod >= (periodicClustPat.get(j).getAveragePeriod() - radius) && lastPeriod <= (periodicClustPat.get(j).getAveragePeriod() + radius)) {
								hitTimes += entry.getValue();
							}
							probability = hitTimes / (float)periodicClustPat.get(j).getClusterNum();
						}
						if (probability == 0.0f) {							
							continue;
						}
					}
					
					probability = probability * cust.distinctItemCount.get(productID);
					recommendedProducts.putIfAbsent(productID, probability);
				}
			}
			
			List<Map.Entry<Integer, Float>> sortAccordingProb = new ArrayList<Map.Entry<Integer, Float>>(recommendedProducts.entrySet());		
			Collections.sort(sortAccordingProb, new Comparator<Map.Entry<Integer, Float>>() {
				public int compare(Map.Entry<Integer, Float> o1, Map.Entry<Integer, Float> o2) {
					return (o1.getValue().compareTo(o2.getValue()));
				}
			});
			
			for (int i1 = sortAccordingProb.size() - 1; 0 <= i1; i1--) {
				custProductRank.putIfAbsent(custID, new ArrayList<>());
				custProductRank.get(custID).add(sortAccordingProb.get(i1).getKey());
			}

		}
				
		int itemsFromPattPred = 0;
		for (Entry<String, ArrayList<Integer>> entry : custProductRank.entrySet()) {			
			int count = entry.getValue().size();
			if (count > recommendedItemsNumber)
				itemsFromPattPred += recommendedItemsNumber;
			else
				itemsFromPattPred += count;
		}

		return itemsFromPattPred;
		
	}
	
	public void preferencePrediction(int recommendedItemsNumber) {
		
		for (int i = 0; i < retailDatabase.getCustomersListSize(); i++) {
			String cust = retailDatabase.getCustomersList().get(i).customerId;
			if (custProductRank.get(cust) == null) {
				custProductRank.putIfAbsent(cust, new ArrayList<>());
				custProductRank.put(cust, sordedByPreference(i));
			} else if (custProductRank.get(cust).size() < recommendedItemsNumber) {
				List<Integer> newRecommendedItem = sordedByPreference(i);				
				for (int j = 0; j < newRecommendedItem.size(); j++) {
					if (custProductRank.get(cust).indexOf(newRecommendedItem.get(j)) < 0)
						custProductRank.get(cust).add(newRecommendedItem.get(j));
				}
			}
		}

	}
	
	private ArrayList<Integer> sordedByPreference(int seqID) {
				
		ArrayList<Integer> sordedProductList = new ArrayList<>();
		
		ArrayList<ProductPreference> productPreferenceList = new ArrayList<>();
		for (Entry<Integer, SeqVerticalBitList> entry : seqVertDatabase.seqVertBitList.entrySet()) {
			int index = entry.getValue().getSupportSeqID().indexOf(seqID);
			if (index >= 0) {
				ProductPreference prodPref = new ProductPreference();
				prodPref.productID = entry.getKey();
				prodPref.frequency = entry.getValue().getFrequency().get(index);
				productPreferenceList.add(prodPref);
			}
		}
				
		if (productPreferenceList.size() == 1) {
			sordedProductList.add(productPreferenceList.get(0).productID);
			return sordedProductList;
		}
		
		List<ProductPreference>  sordedByFrequency = new ArrayList<ProductPreference>(productPreferenceList);
		Collections.sort(sordedByFrequency, new Comparator<ProductPreference>() {
			public int compare(ProductPreference o1, ProductPreference o2) {
				return (o2.frequency - o1.frequency);
			}
		});	
		
		productPreferenceList = null;
		productPreferenceList = new ArrayList<>();

		for (int i = 0; i < sordedByFrequency.size() - 1; ) {
			ArrayList<ProductPreference> tempList = new ArrayList<>();
			tempList.add(sordedByFrequency.get(i));
			int j = i + 1;
			for (; j < sordedByFrequency.size(); j++) {
				if (sordedByFrequency.get(i).frequency == sordedByFrequency.get(j).frequency) {
					tempList.add(sordedByFrequency.get(j));
				} else
					break;
			}
			ArrayList<ProductPreference> tempAfterSord = tempList;
			i = j;
			productPreferenceList.addAll(tempAfterSord);
		}
		
		for (int i = 0; i < productPreferenceList.size(); i++) {
			sordedProductList.add(productPreferenceList.get(i).productID);
		}
		
		return sordedProductList;
		
	}
	
	class ProductPreference {
		int productID;
		int frequency;

	}

	public int calculateMeasures(Map<String, Order> mapTran, int recommendedItemsNumber) {
		
		int totalSelectedItems = 0;
		
		List<EvaluationMetrics> allCustomers = new ArrayList<>();
		for (Entry<String, Order> entry : mapTran.entrySet()) {
			String custId = entry.getKey();
			if (custProductRank.get(custId) == null)
				continue;
			
			List<Integer> predBasket = new ArrayList<>();
			int recomListSize = custProductRank.get(custId).size(); 
			int recomCount =  recommendedItemsNumber > recomListSize ? recomListSize : recommendedItemsNumber; 	
			totalSelectedItems += recomCount;
			for (int i = 0; i < recomCount; i++)
				predBasket.add(custProductRank.get(custId).get(i));
			List<Integer> realBasket = entry.getValue().getOrdProductsList();
			EvaluationMetrics predresult = new EvaluationMetrics();
			predresult.customerId = custId;
			predresult.evaluatePrediction(realBasket, predBasket);
			allCustomers.add(predresult);			
		}
		
		float f1ScoreAll = 0.0f;
		int hitCount = 0;
		for (int i = 0; i < allCustomers.size(); i++) {
			f1ScoreAll += allCustomers.get(i).custF1Score;
			hitCount += allCustomers.get(i).custHit;
		}
		F1Score = f1ScoreAll / allCustomers.size();
		HitRatio = (float)hitCount / allCustomers.size();
		
		return totalSelectedItems;
		
	}

}
