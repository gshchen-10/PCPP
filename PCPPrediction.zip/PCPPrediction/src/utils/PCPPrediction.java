package utils;

import java.text.DecimalFormat;
import java.text.ParseException;

public class PCPPrediction {

	private RetailDatabase retailDatabase;
	private SeqVerticalDatabase seqVertDatabase;
	private PredictedResult predictedResult;
	
	int itemsFromPattPred = 0;
	int totalSelectedItems = 0;
	
	long startTimestamp = 0;
	long endTimeStamp = 0;
	
	public PCPPrediction(String inputFile, int minOrderCount) {
		retailDatabase = new RetailDatabase(inputFile);
		retailDatabase.Preprocessing(minOrderCount);
	}

	public void Running(float coef, float noiRat, int eps, float minpts, int numberOfClusters, int recommendedItemsNumber) throws ParseException {

		MemoryLogger.getInstance().reset();
		startTimestamp = 0;
		endTimeStamp = 0;
		startTimestamp = System.currentTimeMillis();

		seqVertDatabase = new SeqVerticalDatabase(retailDatabase);
//		seqVertDatabase.example();
		seqVertDatabase.periodicItemMining(coef, numberOfClusters);
		seqVertDatabase.periodicClusterPatternMining(coef, numberOfClusters, noiRat, eps, minpts);

		predictedResult = new PredictedResult(retailDatabase, seqVertDatabase);
		itemsFromPattPred = predictedResult.patternsPrediction(recommendedItemsNumber);
		predictedResult.preferencePrediction(recommendedItemsNumber);
		
		totalSelectedItems = predictedResult.calculateMeasures(retailDatabase.testSet, recommendedItemsNumber);
		
		endTimeStamp = System.currentTimeMillis();
		MemoryLogger.getInstance().checkMemory();
		
	}
	
	public void printStatistics(String dataset) {
		DecimalFormat df =new DecimalFormat("#0.0000");		
		StringBuilder r = new StringBuilder(200);	
		r.append("====================================\n"); 
		r.append("F1 score:  " + df.format(predictedResult.F1Score) + " ");
		r.append('\n');
		r.append("Hit ration: " + df.format(predictedResult.HitRatio) + " ");
		r.append('\n');
		r.append("Run time: ");
		r.append((endTimeStamp - startTimestamp) / 1000f);		
		r.append(" s \n");
		r.append("Max memory (mb): " );
		r.append( MemoryLogger.getInstance().getMaxMemory());
		r.append('\n');		
		r.append("====================================\n"); 

		System.out.println(r.toString());		

	}

}
