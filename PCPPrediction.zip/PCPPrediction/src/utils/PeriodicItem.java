package utils;

public class PeriodicItem {
	
	public int item;
	public double meanPeriod;
	public double stdVariance;
	
	public PeriodicItem(int it, double per, double var) {

		this.item = it;
		this.meanPeriod = per;
		this.stdVariance = var;
		
	}

}
