package utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.math3.distribution.NormalDistribution;

import utils.DBScanCluster.DBSCAN;
import utils.DBScanCluster.DPoint;

public class SeqVerticalDatabase {
	
	public RetailDatabase retailDatabase = null;
	public Map<Integer, SeqVerticalBitList> seqVertBitList = new HashMap<>();
	public Map<Integer, ArrayList<Date>> productsSalesRecord = new HashMap<>();
	
	public Map<String, ArrayList<PeriodicItem>> periodicItemList;
	
	public SeqVerticalDatabase(RetailDatabase database) throws ParseException {
		
		this.retailDatabase = database;
		periodicItemList = new HashMap<>();
		
		int custNum = retailDatabase.getCustomersListSize();
		for (int i = 0; i < custNum; i++) {
			Customer cust = retailDatabase.getCustomersList().get(i);
			int prodId = 0;
			int ordSize = cust.getCustOrderSeqSize();
			for (int j = 0; j < ordSize; j++) {
				int prodNum = cust.getCustOrderSeq().get(j).getOrdProductsListSize();
				for (int k = 0; k < prodNum; k++) {
					prodId = cust.getCustOrderSeq().get(j).getOrdProductsList().get(k);				
					seqVertBitList.putIfAbsent(prodId, new SeqVerticalBitList(custNum));
					seqVertBitList.get(prodId).setEmbedding(i, cust.getCustOrderSeq().get(j).orderDate);
				}
			}
		}
		
		for (Entry<Integer, SeqVerticalBitList> entry : seqVertBitList.entrySet()) {
			entry.getValue().preferenceMeasure(retailDatabase);
		}

	}
	
	public void periodicItemMining(float coefficientOfVariation, int numberOfClusters) {
		
		for (Entry<Integer, SeqVerticalBitList> entry : seqVertBitList.entrySet()) {
			int item = entry.getKey();
			int k = 0;
			for (int i = 0 ; i < seqVertBitList.get(item).getEmbeddingsSize(); i++) {
				ArrayList<Date> embeds = seqVertBitList.get(item).getEmbeddings().get(i);
				k = seqVertBitList.get(item).getSupportSeqID().get(i);
				Customer customer = retailDatabase.getCustomersList().get(k);
				if (embeds.size() > numberOfClusters) {
					List<Long> embInterval = new ArrayList<>();
					int n = 0;
					for (; n < embeds.size() - 1; n++) {
						embInterval.add(((embeds.get(n + 1).getTime() - embeds.get(n).getTime())));
					}
					double mean = meanImperat(embInterval);
					double vari = varianceImperat(embInterval, mean);
					double standvari = Math.sqrt(vari);
					if (standvari/mean < coefficientOfVariation) {
						PeriodicItem periodic = new PeriodicItem(item, mean , standvari);
						periodicItemList.putIfAbsent(customer.customerId, new ArrayList<>());
						periodicItemList.get(customer.customerId).add(periodic);
					}
				}
				k++;
			}
		}
				
	}

	public void periodicClusterPatternMining(float coefficientOfVariation, int numberOfClusters, float noiRat, int eps, float minpts) throws ParseException {
		
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");

		for (int i = 0; i < retailDatabase.getCustomersListSize(); i++) {
			Customer cust = retailDatabase.getCustomersList().get(i);
			for (int j = 0; j < cust.getCustOrderSeqSize(); j++) {
				Order ord = cust.getCustOrderSeq().get(j);
				String orderDate = ord.orderDate;
				Date dat = formatter.parse(orderDate);
				for (int k = 0; k < ord.getOrdProductsListSize(); k++) {
					int productId = ord.getOrdProductsList().get(k);
					productsSalesRecord.putIfAbsent(productId, new ArrayList<>());
					productsSalesRecord.get(productId).add(dat);
				}
			}
		}
		
		String dateEnd = "";
		List<PeriodicClusterPattern> periodicClustPatts = null;
		for (int i = 0; i < retailDatabase.testSetDateList.size(); i++) {
			if (dateEnd.equals(retailDatabase.testSetDateList.get(i))) {
				String custID = retailDatabase.testSetCustIdList.get(i);
				int custSeqId = retailDatabase.getCustomersToIndex().get(custID);
				retailDatabase.getCustomersList().get(custSeqId).setPeriodicClustPattList(periodicClustPatts);
				continue;
			}
			
			dateEnd = retailDatabase.testSetDateList.get(i);
			periodicClustPatts = new ArrayList<>();
			Date beginDate = formatter.parse(retailDatabase.beginDate);
			Date endDate = formatter.parse(dateEnd);
			int days = (int)((endDate.getTime() - beginDate.getTime()) / (1000 * 60 * 60 * 24));
			
			for (Entry<Integer, ArrayList<Date>> entry : productsSalesRecord.entrySet()) {
				Collections.sort(entry.getValue());
				ArrayList<DPoint> dataset = generateDataset(entry.getValue(), beginDate, endDate);
				DBSCAN dbscan = new DBSCAN(dataset);
				int aveg = (int)(dataset.size() / (float) days);
				if (aveg == 0)
					aveg = 1;
				
				Map<Integer, ArrayList<Integer>> clusterIdToData = dbscan.Cluster(eps, (int)(aveg * minpts));
				if (clusterIdToData.entrySet().size() > numberOfClusters) {
					ArrayList<Double> clusterCent = new ArrayList<>();
					ArrayList<Integer> clustsDiameter = new ArrayList<>();
					float noiseRatio = 0.0f;
					for (Entry<Integer, ArrayList<Integer>> ent : clusterIdToData.entrySet()) {
						if (ent.getKey() != -1) {
							Collections.sort(ent.getValue());
							int min = ent.getValue().get(0);
							int max = ent.getValue().get(ent.getValue().size() - 1);
							double cent = (min + max) / 2.0f;
							clusterCent.add(cent);
							clustsDiameter.add(max - min + 1);
						} else {
							noiseRatio = (ent.getValue().size() / (float)entry.getValue().size());
						}
					}
					
					ArrayList<Double> periods = new ArrayList<>();
					Collections.sort(clusterCent);

					int k = 0;
					for (; k < clusterCent.size() - 1; k++) {
						periods.add(clusterCent.get(k + 1).doubleValue() - clusterCent.get(k).doubleValue());
					}
					
					double mean = meanImperative(periods);
					double vari = varianceImperative(periods, mean);
					double standvari = Math.sqrt(vari);			
					if (standvari/mean <= coefficientOfVariation && noiseRatio <= noiRat) {
						PeriodicClusterPattern newPattern = new PeriodicClusterPattern(entry.getKey(), clusterCent.size(), noiseRatio, (float)mean, (float)standvari, clustsDiameter, clusterCent.get(k).floatValue());						
						periodicClustPatts.add(newPattern);							
					}
					
				}				

			}
			String custID = retailDatabase.testSetCustIdList.get(i);
			int custSeqId = retailDatabase.getCustomersToIndex().get(custID);
			retailDatabase.getCustomersList().get(custSeqId).setPeriodicClustPattList(periodicClustPatts);

		}

	}
	
	private ArrayList<DPoint> generateDataset(ArrayList<Date> prodSalDatSeq, Date begDate, Date endDate) {
		
		ArrayList<DPoint> allPoint = new ArrayList<>();

		for (int i = 0; i < prodSalDatSeq.size(); i++) {
			if (prodSalDatSeq.get(i).getTime() < endDate.getTime()) {
				long timeDiff = prodSalDatSeq.get(i).getTime() - begDate.getTime();
				DPoint tdp = new DPoint((int)(timeDiff / (1000 * 60 * 60 * 24)));
				allPoint.add(tdp);
			}
		}
		return allPoint;
	}
	
	private double meanImperat(List<Long> population) {
		double average = 0.0;
		for (double p : population) {
			average += p;
		}
		average /= population.size(); 		
		return average;
	}
	
	private double varianceImperat(List<Long> population, double ave) {
		double average = ave; 
		double variance = 0.0;
		for (double p : population) {
			variance += (p - average) * (p - average);
		}
		return variance / population.size();
	}
	
	private double meanImperative(List<Double> population) {
		double average = 0.0;
		for (double p : population) {
			average += p;
		}
		average /= population.size(); 		
		return average;
	}
	
	private double varianceImperative(List<Double> population, double ave) {
		double average = ave; 
		double variance = 0.0;
		for (double p : population) {
			variance += (p - average) * (p - average);
		}
		return variance / population.size();
	}	

	public void example() throws ParseException {
		List<PeriodicClusterPattern> periodicClustPatts = null;
		periodicClustPatts = new ArrayList<>();		
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		ArrayList<Date> exa = new ArrayList<>();
		exa.add(formatter.parse("2010-01-01"));
		exa.add(formatter.parse("2010-01-01"));
		exa.add(formatter.parse("2010-01-01"));
		exa.add(formatter.parse("2010-01-01"));
		exa.add(formatter.parse("2010-01-03"));
		exa.add(formatter.parse("2010-01-04"));
		exa.add(formatter.parse("2010-01-04"));
		exa.add(formatter.parse("2010-01-05"));
		exa.add(formatter.parse("2010-01-07"));
		exa.add(formatter.parse("2010-01-08"));
		exa.add(formatter.parse("2010-01-08"));
		exa.add(formatter.parse("2010-01-08"));
		
		System.out.println(exa);
		
		ArrayList<DPoint> dataset = generateDataset(exa, formatter.parse("2010-01-01"), formatter.parse("2010-01-09"));
		
		DBSCAN dbscan = new DBSCAN(dataset);
		Map<Integer, ArrayList<Integer>> clusterIdToData = dbscan.Cluster(1, 4);
		for (Entry<Integer, ArrayList<Integer>> enty: clusterIdToData.entrySet()) {
			for (int i = 0; i < enty.getValue().size(); i++) {
				System.out.print( enty.getValue().get(i) + "  ");
			}
			System.out.println();
		}	
		
		if (clusterIdToData.entrySet().size() >= 3) {
		
			ArrayList<Double> clusterCent = new ArrayList<>();
			ArrayList<Integer> clustsDiameter = new ArrayList<>();
			float noiseRatio = 0.0f;
			for (Entry<Integer, ArrayList<Integer>> ent : clusterIdToData.entrySet()) {						
				if (ent.getKey() != -1) {
					Collections.sort(ent.getValue());
					int min = ent.getValue().get(0);
					int max = ent.getValue().get(ent.getValue().size() - 1);
					double cent = (min + max) / 2.0f;
					clusterCent.add(cent);
					System.out.println(cent);
					clustsDiameter.add(max - min + 1);
					System.out.println((max - min + 1)/2.0f);
				} else {
					noiseRatio = (ent.getValue().size() / (float)exa.size());
				}
			}
			
			ArrayList<Double> periods = new ArrayList<>();
			Collections.sort(clusterCent);

			int k = 0;
			for (; k < clusterCent.size() - 1; k++) {
				periods.add(clusterCent.get(k + 1).doubleValue() - clusterCent.get(k).doubleValue());
			}
			for (int i = 0; i < periods.size(); i++) {
				System.out.println(periods.get(i));
			}
			
			double mean = meanImperative(periods);
			double vari = varianceImperative(periods, mean);
			double standvari = Math.sqrt(vari);			
			if (standvari/mean <= 0.2) {
				PeriodicClusterPattern newPattern = new PeriodicClusterPattern(1, clusterCent.size(), noiseRatio, (float)mean, (float)standvari, clustsDiameter, clusterCent.get(k).floatValue());						
				periodicClustPatts.add(newPattern);	
				System.out.println(newPattern.toString());				
				Date nextDate = formatter.parse("2010-01-12");
				Date begDate = formatter.parse("2010-01-01");
				float nextTime = (nextDate.getTime() - begDate.getTime()) / (1000 * 60 * 60 * 24);
				float lastPeriod = nextTime - newPattern.getLastCenter();
				float probability = 0;
				if (newPattern.getStandVari() != 0) {
					NormalDistribution dis = new NormalDistribution(newPattern.getAveragePeriod(), newPattern.getStandVari());
					float weightProb = 0.0f;
					for (Entry<Integer, Integer> entry : newPattern.getDiameterDistribute().entrySet()) {
						float radius = entry.getKey() / 2.0f;
						float prob = (float)dis.probability(lastPeriod - radius, lastPeriod + radius);
						weightProb += (prob * entry.getValue());
					}
					probability = weightProb / newPattern.getClusterNum();
				} else {
					int hitTimes = 0;
					for (Entry<Integer, Integer> entry : newPattern.getDiameterDistribute().entrySet()) {
						float radius = entry.getKey() / 2.0f;
						if (lastPeriod >= (newPattern.getAveragePeriod() - radius) && lastPeriod <= (newPattern.getAveragePeriod() + radius)) {
							hitTimes += entry.getValue();
						}
						probability = hitTimes / (float)newPattern.getClusterNum();
					}
					
				}		
				
				System.out.println("Prob:" + probability);
				System.out.println("Weight:" + (probability * 2));				
				
			}		
			
		}	
				
	}	

}
