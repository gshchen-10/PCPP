package utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.BitSet;
import java.util.List;
import java.util.Date;

public class SeqVerticalBitList {
	
	private List<Integer> supportSeqID;	
	private BitSet verticalBitVector;
	private List<ArrayList<Date>> embeddings;
	
	private ArrayList<Integer> frequency;
	private ArrayList<Float> tendency;
	
	SeqVerticalBitList(Integer custCount) {
		supportSeqID = new ArrayList<>();
		verticalBitVector = new BitSet(custCount);
		embeddings = new ArrayList<>();

	}
	
	public void setEmbedding(int seqid, String occur1) throws ParseException {
		
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		Date occur = formatter.parse(occur1);
		
		verticalBitVector.set(seqid, true);
		int index = supportSeqID.indexOf(seqid);		
		if (index < 0) {
			supportSeqID.add(seqid);
			ArrayList<Date> newEmbedding = new ArrayList<>();
			newEmbedding.add(occur);
			embeddings.add(newEmbedding);

		} else {
			embeddings.get(index).add(occur);

		}
	}
	
	public void preferenceMeasure(RetailDatabase retailDatabase) throws ParseException {
		
		frequency = new ArrayList<>();
		tendency = new ArrayList<>();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");

		for (int i = 0; i < embeddings.size(); i++) {
			frequency.add(embeddings.get(i).size());
			Date firstDate = formatter.parse(retailDatabase.getCustomersList().get(supportSeqID.get(i)).getCustOrderSeq().get(0).orderDate);
			long totalOccur = 0;
			for (int j = 0; j < embeddings.get(i).size(); j++) {				
				long occur = (embeddings.get(i).get(j).getTime() - firstDate.getTime())/(1000 * 60 * 60 * 24);
				totalOccur += occur;
			}
			float ten = totalOccur / (float)embeddings.get(i).size();
			tendency.add(ten);			
		}
		
	}
	
	public List<Integer> getSupportSeqID() {
		return supportSeqID;
	}
	
	public int getSupportSeqIDSize(){
		return supportSeqID.size();
	}
	
	public List<ArrayList<Date>> getEmbeddings() {
		return embeddings;
	}
	
	public int getEmbeddingsSize() {
		return embeddings.size();
	}
	
	public BitSet getVerticalBitVector() {
		return verticalBitVector;
	}
	
	public ArrayList<Integer> getFrequency() {
		return frequency;
	}

	public void setFrequency(ArrayList<Integer> frequency) {
		this.frequency = frequency;
	}

	public ArrayList<Float> getTendency() {
		return tendency;
	}

	public void setTendency(ArrayList<Float> tendency) {
		this.tendency = tendency;
	}

}
